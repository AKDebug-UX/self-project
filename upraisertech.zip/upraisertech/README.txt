Salaudeen Lateef WebSite for web develop. Designed with ♥️ and creativity by UpraiserTech.com 

Product Page: https://wwww.UpraiserTech.com/

Credits:

    Demo Images:
        Unsplash:       	(https://www.unsplash.com)

    Icons:
		Themify Icons: 		(https://themify.me/themify-icons)

	Other:
		JQuery: 			(https://www.jquery.com)
		Bootstrap: 			(https://www.getbootstrap.com)
		Bootstrap Affix: 	(http://getbootstrap.com/javascript/#affix)  
		Isotope: 			(https://isotope.metafizzy.co/) 
		Google Maps:		(https://maps.google.com)
